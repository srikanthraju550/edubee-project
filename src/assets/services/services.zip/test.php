<?php
echo md5('admin123');
?>